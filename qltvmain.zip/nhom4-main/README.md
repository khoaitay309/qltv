# GROUP_04-OOP-N03

## Hệ Thống Quản Lý Thư Viện

### Giới Thiệu Dự Án
Dự án này là một hệ thống quản lý thư viện, giúp tối ưu hóa và cải thiện hiệu quả hoạt động của các thư viện. 
Hệ thống cho phép người quản lý thư viện dễ dàng thêm, chỉnh sửa thông tin sách và theo dõi người mượn.
Người dùng cũng có thể xem thông tin sách có sẵn và tình trạng mượn trả của mình.
---
## Demo Dự án
[Link demo](https://www.youtube.com/watch?v=P4wK47PdgqY&t=103s)

**Chi tiết dự án:**  [Quản Lý thự Viện](https://github.com/khoaitay309/nhom4/tree/duan-QuanLyThuVien)
