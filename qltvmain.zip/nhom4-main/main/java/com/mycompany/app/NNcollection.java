public class NNcollection{

}