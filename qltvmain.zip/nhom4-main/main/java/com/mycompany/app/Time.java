public class Time{
    
}