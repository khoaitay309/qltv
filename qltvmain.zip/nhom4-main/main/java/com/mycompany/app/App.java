public class App{
    public static void main(String[] args){
        Book myBook = new Book();
        Time myTime = new Time();
        Recursion myRecursion = new Recursion();
        NNcollection myNNcollection = new NNcollection();
        NameNumber myNameNumber = new NameNumber();
        
    }
}