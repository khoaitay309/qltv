public class BreaK {
    public static void main(String[] args) {
        for(int i = 0; i < 10; i++){
            System.err.println(i);
            if(i == 5){
                break;
            }
        }
    }
}
