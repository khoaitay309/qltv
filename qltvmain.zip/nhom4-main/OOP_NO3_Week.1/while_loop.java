public class while_loop {
    public static void main(String[] args){
        int a = 0;
        while (a < 5) {
            System.out.println(a );
            a++; 
        }
    }
}
